<div>
	<h1>Sudecor Attendance Report</h1>
	<h3>from:<?php echo e($query_info); ?></h3>
	<br>
	<br>
	<?php $__currentLoopData = $full_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $individual_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<h3>Name: <?php echo e($individual_info[0][0]->name); ?></h3>	
		<table>
			<thead>
				<tr>
					<th>Time in</th>
					<th>Time out</th>
					<th>Regular Hours</th>
					<th>Over Time</th>
					<th>Sunday</th>
					<th>Holiday</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $individual_info[0][1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($info->time_in); ?></td>
						<td><?php echo e($info->time_out); ?></td>
						<td><?php echo e($info->regular_hour); ?></td>
						<td><?php echo e($info->over_time); ?></td>
						<td><?php echo e($info->sunday); ?></td>
						<td><?php echo e($info->holiday); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		
			
		<h4>Regular Hour: <?php echo e($individual_info[0][2][0]); ?></h4>
		<h4>Over Time: <?php echo e($individual_info[0][2][1]); ?></h4>
		<h4>Sunday: <?php echo e($individual_info[0][2][2]); ?></h4>
		<h4>Holiday: <?php echo e($individual_info[0][2][3]); ?></h4>
		<br>
		<br>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
</div>


<style type="text/css">
	div{
		font-family: sans-serif;
	}
	table tr td{
		border:solid;
	}
</style><?php /**PATH C:\xampp\htdocs\sudecor_server2\resources\views/print/print_to_excel.blade.php ENDPATH**/ ?>